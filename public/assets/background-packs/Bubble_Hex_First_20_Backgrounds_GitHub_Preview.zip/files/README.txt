Bubble Hex First 20 Backgrounds — compact GitHub preview pack
Format: AVIF | Resolution: 256x144 | Ratio: 16:9
Full-resolution PNG source pack retained separately.
